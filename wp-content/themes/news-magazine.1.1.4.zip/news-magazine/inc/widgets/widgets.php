<?php
/// include widgets

/// include Advertisement Widget

require_once( 'widget-advert.php' );

/// include Advertisement Widget

require_once( 'widget-adsens.php' );

// incude Category Post
require_once( 'widget-category.php' );

// incude Event Category Post
require_once( 'widget-events-category.php' );

// incude social icons
require_once( 'widget-social-icons.php' );
?>